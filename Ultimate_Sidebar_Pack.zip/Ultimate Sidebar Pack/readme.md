Hello This will tell you how to change the pack as well as add it to your own. 

1. How do I edit locations and size?
Go in the Hud_screen.json and edit the things that I marked for you as needed.

2. How do I change the images?
go in the textures and edit those pngs 

3. How do I add it to my pack?
Put all the files in here in your recource pack. 

4. Who made this? 
Sanji#8518